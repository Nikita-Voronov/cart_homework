<?php
require 'list.php';
$id=$_POST['id'];

$producti=$product[$id];
$price=$prod['price'];
$_SESSION['cart']['items'][$id];
?>